import './App.css';
import {Rockets} from "./components";

function App() {
  return (
    <div >
      <Rockets/>

    </div>
  );
}

export default App;
